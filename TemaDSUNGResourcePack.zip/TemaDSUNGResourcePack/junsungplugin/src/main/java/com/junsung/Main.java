package com.junsung;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin implements Listener, CommandExecutor {

    private static final long ATTENDANCE_COOLDOWN = 24 * 60 * 60 * 1000L;
    private static final int MAX_HOMES = 3;
    private boolean isServerLocked = false;
    private final Map<UUID, Integer> money = new HashMap<>();
    private final Map<UUID, Integer> attendanceCount = new HashMap<>();
    private final Map<UUID, Long> lastAttendance = new HashMap<>();
    private final Map<UUID, Map<String, Integer>> playerStocks = new HashMap<>();
    private final Map<String, Integer> stockPrices = new HashMap<>();
    private final Map<UUID, UUID> tpaRequests = new HashMap<>();
    private final Map<UUID, Map<String, Location>> playerHomes = new HashMap<>();
    private final Map<Material, int[]> shopItems = new HashMap<>();

    @Override
    public void onEnable() {
        Bukkit.getPluginManager().registerEvents(this, this);
        String[] cmds = {"chat", "돈", "상점", "주식", "도박", "출석", "tpa", "tpaccept", "tpdeny", "sethome", "home"};
        for (String c : cmds) {
            if (getCommand(c) != null) {
                getCommand(c).setExecutor(this);
            }
        }

        stockPrices.put("마크전자", 700);
        stockPrices.put("스케이트하이닉스", 1300);
        stockPrices.put("초콜렛", 600);
        stockPrices.put("초록창", 2500);

        // 광물 및 희귀 자원
        shopItems.put(Material.NETHERITE_INGOT, new int[]{3000, 1200});
        shopItems.put(Material.DIAMOND, new int[]{600, 200});
        shopItems.put(Material.EMERALD, new int[]{400, 100});
        shopItems.put(Material.GOLD_INGOT, new int[]{250, 80});
        shopItems.put(Material.IRON_INGOT, new int[]{120, 40});
        shopItems.put(Material.COPPER_INGOT, new int[]{50, 10});
        
        // 보스 및 특수 아이템
        shopItems.put(Material.DRAGON_EGG, new int[]{20000, 8000});
        shopItems.put(Material.NETHER_STAR, new int[]{10000, 4000});
        shopItems.put(Material.BEACON, new int[]{5000, 2000});
        shopItems.put(Material.ENCHANTED_GOLDEN_APPLE, new int[]{7000, 2000});
        shopItems.put(Material.ELYTRA, new int[]{15000, 5000});
        shopItems.put(Material.TOTEM_OF_UNDYING, new int[]{3000, 1000});
        
        // 건축 및 기본 블록
        shopItems.put(Material.DEEPSLATE_TILES, new int[]{20, 2});
        shopItems.put(Material.SMOOTH_STONE, new int[]{15, 1});
        shopItems.put(Material.GLASS, new int[]{30, 5});
        shopItems.put(Material.SEA_LANTERN, new int[]{200, 50});
        shopItems.put(Material.GLOWSTONE, new int[]{150, 40});
        
        // 농사 및 기타
        shopItems.put(Material.GOLDEN_CARROT, new int[]{100, 20});
        shopItems.put(Material.SLIME_BALL, new int[]{300, 100});
        shopItems.put(Material.ENDER_PEARL, new int[]{200, 50});

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            stockPrices.replaceAll((stock, currentPrice) -> {
                double change = (new Random().nextDouble() * 0.06) - 0.03;
                return Math.max(10, (int) (currentPrice * (1 + change)));
            });
        }, 0L, 1200L);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("플레이어만 사용할 수 있는 명령어입니다.");
            return true;
        }

        UUID uuid = player.getUniqueId();
        String name = player.getName();

        switch (label.toLowerCase()) {
            case "chat" -> {
                if (player.isOp() && args.length > 0) {
                    isServerLocked = args[0].equalsIgnoreCase("off");
                    Bukkit.broadcastMessage(isServerLocked ? "§c[!] 서버 잠금 (관리자 전용)" : "§a[!] 서버 잠금 해제");
                }
            }
            case "돈" -> player.sendMessage("§6" + name + "님, 잔액: " + money.getOrDefault(uuid, 10000) + "원");
            case "출석" -> handleAttendance(player);
            case "상점" -> openShop(player);
            case "도박" -> handleGambling(player);
            case "주식" -> handleStock(player, args);
            case "tpa" -> handleTpa(player, args);
            case "tpaccept" -> handleTpaAccept(player);
            case "tpdeny" -> handleTpaDeny(player);
            case "sethome" -> handleSetHome(player, args);
            case "home" -> handleHome(player, args);
            default -> player.sendMessage("§c알 수 없는 명령어입니다.");
        }
        return true;
    }

    private void handleAttendance(Player player) {
        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        long last = lastAttendance.getOrDefault(uuid, 0L);

        if (now - last < ATTENDANCE_COOLDOWN) {
            long remaining = ATTENDANCE_COOLDOWN - (now - last);
            long hours = remaining / 3600000;
            long minutes = (remaining % 3600000) / 60000;
            player.sendMessage("§c" + player.getName() + "님, 이미 출석하셨습니다. 남은 대기시간: " + hours + "시간 " + minutes + "분");
            return;
        }

        int count = attendanceCount.getOrDefault(uuid, 0) + 1;
        attendanceCount.put(uuid, count);
        lastAttendance.put(uuid, now);

        player.sendMessage("§6" + player.getName() + "님, 안녕하세요! 출석 체크가 완료되었습니다.");
        if (count == 1) {
            player.getInventory().addItem(
                    new ItemStack(Material.DIAMOND_HELMET),
                    new ItemStack(Material.DIAMOND_CHESTPLATE),
                    new ItemStack(Material.DIAMOND_LEGGINGS),
                    new ItemStack(Material.DIAMOND_BOOTS)
            );
            player.sendMessage("§b[출석] 1일차 보상: 다이아 풀세트! (초보 니가ㅋㅋ)");
        } else {
            money.put(uuid, money.getOrDefault(uuid, 10000) + 100);
            player.sendMessage("§b[출석] " + count + "일차 보상: 100포인트 지급 완료!");
        }
    }

    private void handleGambling(Player player) {
        UUID uuid = player.getUniqueId();
        int bal = money.getOrDefault(uuid, 10000);
        if (bal < 1000) {
            player.sendMessage("§c" + player.getName() + "님, 돈이 부족합니다. 최소 1000원 필요합니다.");
            return;
        }
        money.put(uuid, bal - 1000);
        if (new Random().nextInt(100) < 40) {
            money.put(uuid, bal + 2500);
            player.sendMessage("§a[도박] " + player.getName() + "님, 도박 성공! 2500원 획득!");
        } else {
            player.sendMessage("§7[도박] " + player.getName() + "님, 꽝! 1000원을 잃었습니다.");
        }
    }

    private void handleStock(Player player, String[] args) {
        if (args.length == 0) {
            player.sendMessage("§b[ 마크 증권 ]");
            stockPrices.forEach((k, v) -> player.sendMessage("§f" + k + ": §e" + v + "포인트"));
            player.sendMessage("§7사용법: /주식 구매|판매 종목 수량");
            return;
        }

        if (args.length < 3) {
            player.sendMessage("§c사용법: /주식 구매|판매 종목 수량");
            return;
        }

        String action = args[0];
        String stockName = args[1];
        int qty;
        try {
            qty = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            player.sendMessage("§c수량은 숫자로 입력해주세요.");
            return;
        }

        if (qty <= 0) {
            player.sendMessage("§c수량은 1 이상이어야 합니다.");
            return;
        }

        if (!stockPrices.containsKey(stockName)) {
            player.sendMessage("§c해당 종목을 찾을 수 없습니다: " + stockName);
            return;
        }

        int price = stockPrices.get(stockName);
        UUID uuid = player.getUniqueId();
        int bal = money.getOrDefault(uuid, 10000);
        Map<String, Integer> myStocks = playerStocks.computeIfAbsent(uuid, k -> new HashMap<>());

        if (action.equalsIgnoreCase("구매")) {
            int cost = price * qty;
            if (bal < cost) {
                player.sendMessage("§c" + player.getName() + "님, 잔액이 부족합니다. 필요: " + cost + "원");
                return;
            }
            money.put(uuid, bal - cost);
            myStocks.put(stockName, myStocks.getOrDefault(stockName, 0) + qty);
            player.sendMessage("§a" + player.getName() + "님, " + stockName + " " + qty + "주를 구매했습니다.");
        } else if (action.equalsIgnoreCase("판매")) {
            int owned = myStocks.getOrDefault(stockName, 0);
            if (owned < qty) {
                player.sendMessage("§c" + player.getName() + "님, 보유 주식이 부족합니다.");
                return;
            }
            money.put(uuid, bal + price * qty);
            myStocks.put(stockName, owned - qty);
            player.sendMessage("§e" + player.getName() + "님, " + stockName + " " + qty + "주를 판매했습니다.");
        } else {
            player.sendMessage("§c명령어는 구매 또는 판매만 가능합니다.");
        }
    }

    private void handleTpa(Player player, String[] args) {
        if (args.length == 0) {
            player.sendMessage("§c사용법: /tpa <플레이어이름>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            player.sendMessage("§c대상 플레이어를 찾을 수 없습니다.");
            return;
        }
        if (target.getUniqueId().equals(player.getUniqueId())) {
            player.sendMessage("§c자기 자신에게는 신청할 수 없습니다.");
            return;
        }

        tpaRequests.put(target.getUniqueId(), player.getUniqueId());
        player.sendMessage("§e" + target.getName() + "님에게 TPA 요청을 전송했습니다.");
        target.sendMessage("§e" + player.getName() + "님이 TPA 요청을 보냈습니다.");
        target.sendMessage("§a수락하려면 /tpaccept, 거부하려면 /tpdeny 를 입력하세요.");
    }

    private void handleTpaAccept(Player player) {
        UUID uuid = player.getUniqueId();
        if (!tpaRequests.containsKey(uuid)) {
            player.sendMessage("§cTPA 요청이 없습니다.");
            return;
        }
        Player requester = Bukkit.getPlayer(tpaRequests.get(uuid));
        if (requester == null) {
            player.sendMessage("§c요청한 플레이어가 접속 중이 아닙니다.");
            tpaRequests.remove(uuid);
            return;
        }
        requester.teleport(player.getLocation());
        requester.sendMessage("§a[TPA] " + player.getName() + "님이 요청을 수락했습니다.");
        player.sendMessage("§aTPA 요청을 수락했습니다.");
        tpaRequests.remove(uuid);
    }

    private void handleTpaDeny(Player player) {
        UUID uuid = player.getUniqueId();
        if (!tpaRequests.containsKey(uuid)) {
            player.sendMessage("§cTPA 요청이 없습니다.");
            return;
        }
        Player requester = Bukkit.getPlayer(tpaRequests.get(uuid));
        if (requester != null) {
            requester.sendMessage("§c[TPA] " + player.getName() + "님이 요청을 거부했습니다.");
        }
        player.sendMessage("§cTPA 요청을 거부했습니다.");
        tpaRequests.remove(uuid);
    }

    private void handleSetHome(Player player, String[] args) {
        UUID uuid = player.getUniqueId();
        Map<String, Location> homes = playerHomes.computeIfAbsent(uuid, k -> new HashMap<>());
        String homeName = args.length > 0 ? args[0].toLowerCase() : "home";

        if (!homeName.matches("[a-z0-9_-]{1,16}")) {
            player.sendMessage("§c홈 이름은 영문 소문자, 숫자, 밑줄 또는 대시만 사용 가능합니다.");
            return;
        }

        if (!homes.containsKey(homeName) && homes.size() >= MAX_HOMES) {
            player.sendMessage("§c최대 " + MAX_HOMES + "개의 홈만 저장할 수 있습니다. 기존 홈을 삭제하거나 /home list로 확인하세요.");
            return;
        }

        homes.put(homeName, player.getLocation());
        player.sendMessage("§a홈 " + homeName + "(이)가 저장되었습니다. /home " + homeName + "으로 이동하세요.");
    }

    private void handleHome(Player player, String[] args) {
        UUID uuid = player.getUniqueId();
        Map<String, Location> homes = playerHomes.get(uuid);
        if (homes == null || homes.isEmpty()) {
            player.sendMessage("§c저장된 홈이 없습니다. /sethome 으로 홈을 저장하세요.");
            return;
        }

        if (args.length == 0) {
            if (homes.size() == 1) {
                Location target = homes.values().iterator().next();
                player.teleport(target);
                player.sendMessage("§a홈으로 이동했습니다.");
                return;
            }
            if (homes.containsKey("home")) {
                player.teleport(homes.get("home"));
                player.sendMessage("§a홈으로 이동했습니다.");
                return;
            }
            player.sendMessage("§b사용 가능한 홈:");
            homes.keySet().forEach(name -> player.sendMessage("§f- " + name));
            player.sendMessage("§7사용법: /home <홈이름>");
            return;
        }

        if (args[0].equalsIgnoreCase("list")) {
            player.sendMessage("§b저장된 홈 목록:");
            homes.keySet().forEach(name -> player.sendMessage("§f- " + name));
            return;
        }

        String requested = args[0].toLowerCase();
        if (!homes.containsKey(requested)) {
            player.sendMessage("§c해당 이름의 홈이 없습니다: " + requested);
            return;
        }

        player.teleport(homes.get(requested));
        player.sendMessage("§a홈 " + requested + " 으로 이동했습니다.");
    }

    public void openShop(Player player) {
        Inventory shop = Bukkit.createInventory(null, 54, "§8[ 중앙 상점 - 마크 아이템 ]");
        
        int slot = 0;
        for (Map.Entry<Material, int[]> entry : shopItems.entrySet()) {
            if (slot >= 54) break;
            Material material = entry.getKey();
            int[] prices = entry.getValue();
            int buyPrice = prices[0];
            int sellPrice = prices[1];
            
            ItemStack item = new ItemStack(material);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName("§b" + material.name().replace("_", " "));
                meta.setLore(List.of(
                    "§f구매: §e" + buyPrice + "원",
                    "§f판매: §e" + sellPrice + "원",
                    "§a좌클릭: 구매 / 우클릭: 판매"
                ));
                item.setItemMeta(meta);
            }
            shop.setItem(slot, item);
            slot++;
        }
        player.openInventory(shop);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!event.getView().getTitle().startsWith("§8[ 중앙 상점")) return;
        event.setCancelled(true);
        Player p = (Player) event.getWhoClicked();
        if (event.getCurrentItem() == null) return;

        Material itemType = event.getCurrentItem().getType();
        if (!shopItems.containsKey(itemType)) return;

        int[] prices = shopItems.get(itemType);
        int buyPrice = prices[0];
        int sellPrice = prices[1];
        int bal = money.getOrDefault(p.getUniqueId(), 10000);

        if (event.isLeftClick()) {
            if (bal >= buyPrice) {
                money.put(p.getUniqueId(), bal - buyPrice);
                p.getInventory().addItem(new ItemStack(itemType));
                p.sendMessage("§a구매 완료! (" + itemType.name() + " 1개)");
                getLogger().info("[상점 로그] " + p.getName() + "님이 " + itemType.name() + "을(를) " + buyPrice + "원에 구매했습니다.");
            } else {
                p.sendMessage("§c돈이 부족합니다. 필요: " + buyPrice + "원");
            }
        } else if (event.isRightClick()) {
            if (p.getInventory().contains(itemType)) {
                p.getInventory().removeItem(new ItemStack(itemType, 1));
                money.put(p.getUniqueId(), bal + sellPrice);
                p.sendMessage("§e판매 완료! (" + itemType.name() + " 1개 = " + sellPrice + "원)");
                getLogger().info("[상점 로그] " + p.getName() + "님이 " + itemType.name() + "을(를) " + sellPrice + "원에 판매했습니다.");
            } else {
                p.sendMessage("§c해당 아이템이 없습니다.");
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent e) {
        if (isServerLocked && !e.getPlayer().isOp()) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§c[!] 서버 잠금 상태입니다.");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCmd(PlayerCommandPreprocessEvent e) {
        Player player = e.getPlayer();
        String message = e.getMessage().toLowerCase();
        
        // 우리 플러그인 명령어는 항상 허용 (OP 없어도 OK)
        if (message.startsWith("/chat") || message.startsWith("/돈") || 
            message.startsWith("/출석") || message.startsWith("/상점") || 
            message.startsWith("/도박") || message.startsWith("/주식") || 
            message.startsWith("/tpa") || message.startsWith("/tpaccept") || 
            message.startsWith("/tpdeny") || message.startsWith("/sethome") || 
            message.startsWith("/home")) {
            
            // 서버 잠금 상태 체크
            if (isServerLocked && !player.isOp() && !message.startsWith("/chat")) {
                e.setCancelled(true);
                player.sendMessage("§c[!] 서버 잠금 상태입니다.");
            }
            return; // 우리 명령어는 여기서 끝
        }
        
        // 일반 유저(non-OP)의 정보 유출 명령어 차단
        if (!player.isOp()) {
            if (message.startsWith("/seed") || message.startsWith("/me") || 
                message.startsWith("/help") || message.startsWith("/plugins") ||
                message.startsWith("/version") || message.startsWith("/server")) {
                e.setCancelled(true);
                player.sendMessage("§c[!] 이 명령어는 사용할 수 없습니다.");
                return;
            }
        }
    }
}
